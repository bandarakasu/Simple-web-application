import { useState, useRef, useEffect } from 'react'
import { ExternalLink, Play, Star, ArrowRight } from 'lucide-react'

interface ProjectCardProps {
  title: string
  description: string
  icon: React.ReactNode
  color: string
  href?: string
  onClick?: () => void
  mousePosition?: { x: number; y: number }
  isDarkMode?: boolean
}

export default function ProjectCard({ 
  title, 
  description, 
  icon, 
  color, 
  href, 
  onClick,
  mousePosition = { x: 0, y: 0 },
  isDarkMode = true
}: ProjectCardProps) {
  const [isHovered, setIsHovered] = useState(false)
  const [isPressed, setIsPressed] = useState(false)
  const [rotateX, setRotateX] = useState(0)
  const [rotateY, setRotateY] = useState(0)
  const [glowPosition, setGlowPosition] = useState({ x: 50, y: 50 })
  const cardRef = useRef<HTMLDivElement>(null)

  const handleClick = () => {
    if (href) {
      window.open(href, '_blank')
    } else if (onClick) {
      onClick()
    }
  }

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return
    
    const rect = cardRef.current.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top
    const centerX = rect.width / 2
    const centerY = rect.height / 2
    
    // Calculate rotation based on mouse position
    const rotateXValue = ((y - centerY) / centerY) * -10
    const rotateYValue = ((x - centerX) / centerX) * 10
    
    setRotateX(rotateXValue)
    setRotateY(rotateYValue)
    
    // Update glow position
    setGlowPosition({
      x: (x / rect.width) * 100,
      y: (y / rect.height) * 100
    })
  }

  const handleMouseEnter = () => {
    setIsHovered(true)
  }

  const handleMouseLeave = () => {
    setIsHovered(false)
    setIsPressed(false)
    setRotateX(0)
    setRotateY(0)
  }

  const handleMouseDown = () => {
    setIsPressed(true)
  }

  const handleMouseUp = () => {
    setIsPressed(false)
  }

  return (
    <div
      ref={cardRef}
      className={`
        relative group cursor-pointer
        transform-gpu transition-all duration-300 ease-out
        ${isHovered ? 'z-20' : 'z-10'}
      `}
      style={{
        transform: `
          perspective(1000px)
          rotateX(${rotateX}deg)
          rotateY(${rotateY}deg)
          ${isHovered ? 'translateY(-12px) scale(1.05)' : 'translateY(0) scale(1)'}
          ${isPressed ? 'scale(0.95)' : ''}
        `,
        transformStyle: 'preserve-3d'
      }}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      onMouseMove={handleMouseMove}
      onMouseDown={handleMouseDown}
      onMouseUp={handleMouseUp}
      onClick={handleClick}
    >
      {/* Card Container with Reduced Padding */}
      <div className={`
        relative bg-gradient-to-br ${color}
        p-0.5 rounded-xl
        shadow-lg transition-all duration-500
        ${isHovered ? 'shadow-2xl' : ''}
        ${isDarkMode ? '' : 'shadow-gray-300'}
      `}>
        {/* Glass effect background */}
        <div className={`
          absolute inset-0 backdrop-blur-md rounded-xl transition-all duration-500
          ${isDarkMode ? 'bg-gray-900/95' : 'bg-white/95'}
        `} />
        
        {/* Dynamic glow effect */}
        <div 
          className="absolute inset-0 rounded-xl opacity-0 transition-opacity duration-300 pointer-events-none"
          style={{
            background: `radial-gradient(circle at ${glowPosition.x}% ${glowPosition.y}%, rgba(255,255,255,0.3) 0%, transparent 50%)`,
            opacity: isHovered ? 1 : 0
          }}
        />
        
        {/* Content with Reduced Padding */}
        <div className={`
          relative rounded-xl p-4 h-full flex flex-col items-center justify-center text-center transition-all duration-500
          ${isDarkMode ? 'bg-gray-900/50' : 'bg-gray-50/50'}
        `}>
          {/* Animated icon container */}
          <div className={`
            relative w-12 h-12 rounded-xl
            bg-gradient-to-br ${color}
            flex items-center justify-center
            mb-3 transform transition-all duration-500
            ${isHovered ? 'scale-125 rotate-12' : 'scale-100 rotate-0'}
          `}>
            <div className="text-white">
              {icon}
            </div>
            
            {/* Floating stars around icon */}
            {isHovered && (
              <>
                <Star className="absolute -top-2 -right-2 w-3 h-3 text-yellow-400 animate-pulse" />
                <Star className="absolute -bottom-2 -left-2 w-3 h-3 text-yellow-400 animate-pulse" style={{ animationDelay: '0.3s' }} />
              </>
            )}
          </div>

          {/* Title with animation */}
          <h3 className={`
            text-lg font-bold mb-1 transition-all duration-300
            ${isDarkMode ? 'text-white' : 'text-gray-800'}
          `}>
            <span className={`
              inline-block transition-all duration-300
              ${isHovered ? 'text-transparent bg-clip-text bg-gradient-to-r from-white to-gray-300' : ''}
            `}>
              {title}
            </span>
          </h3>

          {/* Description */}
          <p className={`
            text-xs transition-all duration-300
            ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}
          `}>
            {description}
          </p>

          {/* Enhanced action indicator */}
          <div className={`
            mt-3 flex items-center gap-1.5
            text-xs transition-all duration-300
            ${isDarkMode ? 'text-white/80' : 'text-gray-700/80'}
            transform transition-all duration-300
            ${isHovered ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0'}
          `}>
            {href ? (
              <>
                <ExternalLink className="w-3 h-3 animate-bounce" />
                <span>Open</span>
                <ArrowRight className="w-3 h-3 animate-bounce" style={{ animationDelay: '0.1s' }} />
              </>
            ) : (
              <>
                <Play className="w-3 h-3 animate-pulse" />
                <span>Launch</span>
                <ArrowRight className="w-3 h-3 animate-pulse" style={{ animationDelay: '0.1s' }} />
              </>
            )}
          </div>

          {/* Particle effects on hover */}
          {isHovered && (
            <div className="absolute inset-0 pointer-events-none">
              {[...Array(3)].map((_, i) => (
                <div
                  key={i}
                  className="absolute w-1 h-1 bg-white rounded-full animate-ping"
                  style={{
                    left: `${20 + i * 30}%`,
                    top: `${10 + i * 15}%`,
                    animationDelay: `${i * 0.2}s`,
                    animationDuration: '1.5s'
                  }}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}