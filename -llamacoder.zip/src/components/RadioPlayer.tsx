import { useState, useRef, useEffect } from 'react'
import { ArrowLeft, Play, Pause, Volume2, Radio as RadioIcon, AlertCircle } from 'lucide-react'
import { radioStations } from '../utils/radioStations'

interface RadioPlayerProps {
  onBack: () => void
  isDarkMode: boolean
}

export default function RadioPlayer({ onBack, isDarkMode }: RadioPlayerProps) {
  const [currentStation, setCurrentStation] = useState(radioStations[0])
  const [isPlaying, setIsPlaying] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [volume, setVolume] = useState(0.7)
  const [error, setError] = useState<string | null>(null)
  const [canPlay, setCanPlay] = useState(false)
  const audioRef = useRef<HTMLAudioElement>(null)

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume
    }
  }, [volume])

  useEffect(() => {
    const audio = audioRef.current
    if (!audio) return

    const handleCanPlay = () => {
      setCanPlay(true)
      setIsLoading(false)
      setError(null)
    }

    const handleError = (e: Event) => {
      console.error('Audio error:', e)
      setError('Failed to load station. Please try another.')
      setIsLoading(false)
      setIsPlaying(false)
      setCanPlay(false)
    }

    const handleLoadStart = () => {
      setIsLoading(true)
      setCanPlay(false)
      setError(null)
    }

    const handlePlaying = () => {
      setIsPlaying(true)
      setIsLoading(false)
      setError(null)
    }

    const handlePause = () => {
      setIsPlaying(false)
    }

    const handleEnded = () => {
      setIsPlaying(false)
    }

    audio.addEventListener('canplay', handleCanPlay)
    audio.addEventListener('error', handleError)
    audio.addEventListener('loadstart', handleLoadStart)
    audio.addEventListener('playing', handlePlaying)
    audio.addEventListener('pause', handlePause)
    audio.addEventListener('ended', handleEnded)

    return () => {
      audio.removeEventListener('canplay', handleCanPlay)
      audio.removeEventListener('error', handleError)
      audio.removeEventListener('loadstart', handleLoadStart)
      audio.removeEventListener('playing', handlePlaying)
      audio.removeEventListener('pause', handlePause)
      audio.removeEventListener('ended', handleEnded)
    }
  }, [])

  const handleStationChange = (stationUrl: string) => {
    const station = radioStations.find(s => s.streamUrl === stationUrl)
    if (station && audioRef.current) {
      setCurrentStation(station)
      setError(null)
      setIsLoading(true)
      setIsPlaying(false)
      setCanPlay(false)
      
      // Reset and load new station
      audioRef.current.pause()
      audioRef.current.src = ''
      audioRef.current.load()
      
      // Set new source and load
      setTimeout(() => {
        if (audioRef.current) {
          audioRef.current.src = stationUrl
          audioRef.current.crossOrigin = 'anonymous'
          audioRef.current.load()
        }
      }, 100)
    }
  }

  const togglePlayPause = async () => {
    if (!audioRef.current || !canPlay) return

    try {
      if (isPlaying) {
        audioRef.current.pause()
        setIsPlaying(false)
      } else {
        setIsLoading(true)
        await audioRef.current.play()
        setIsPlaying(true)
        setIsLoading(false)
      }
    } catch (err) {
      console.error('Play error:', err)
      setError('Failed to play. Please try again.')
      setIsLoading(false)
      setIsPlaying(false)
    }
  }

  const handleBack = () => {
    if (audioRef.current) {
      audioRef.current.pause()
      audioRef.current.src = ''
    }
    setIsPlaying(false)
    setCanPlay(false)
    setError(null)
    onBack()
  }

  // Auto-load first station
  useEffect(() => {
    if (audioRef.current && currentStation) {
      audioRef.current.src = currentStation.streamUrl
      audioRef.current.crossOrigin = 'anonymous'
      audioRef.current.load()
    }
  }, [])

  return (
    <div className={`min-h-screen flex flex-col items-center justify-center p-6 transition-all duration-500 ${
      isDarkMode ? 'bg-gray-900' : 'bg-gray-50'
    }`}>
      <audio 
        ref={audioRef} 
        preload="metadata"
        crossOrigin="anonymous"
      />
      
      <div className={`w-full max-w-md transition-all duration-500 ${
        isDarkMode ? 'bg-gray-800/90' : 'bg-white/90'
      } backdrop-blur-lg rounded-3xl shadow-2xl p-8`}>
        
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <button
            onClick={handleBack}
            className={`
              flex items-center gap-2 px-4 py-2 rounded-xl
              transition-all duration-300 hover:scale-105
              ${isDarkMode 
                ? 'bg-gray-700 text-white hover:bg-gray-600' 
                : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
              }
            `}
          >
            <ArrowLeft className="w-5 h-5" />
            <span>ආපසු</span>
          </button>
          
          <div className="flex items-center gap-2">
            <RadioIcon className={`w-6 h-6 animate-pulse ${
              isPlaying ? 'text-green-500' : (isDarkMode ? 'text-purple-400' : 'text-purple-600')
            }`} />
            <span className={`text-sm font-medium ${
              isDarkMode ? 'text-gray-300' : 'text-gray-600'
            }`}>
              {isPlaying ? 'NOW PLAYING' : (canPlay ? 'READY' : 'LOADING')}
            </span>
          </div>
        </div>

        {/* Station Info */}
        <div className="text-center mb-8">
          <h2 className={`text-2xl font-bold mb-2 transition-colors duration-500 ${
            isDarkMode ? 'text-white' : 'text-gray-800'
          }`}>
            {currentStation.name}
          </h2>
          <p className={`text-sm transition-colors duration-500 ${
            isDarkMode ? 'text-gray-400' : 'text-gray-600'
          }`}>
            නාලිකාවක් තෝරන්න
          </p>
        </div>

        {/* Error Message */}
        {error && (
          <div className={`
            mb-6 p-3 rounded-lg flex items-center gap-2
            ${isDarkMode ? 'bg-red-900/50 text-red-300' : 'bg-red-100 text-red-700'}
          `}>
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span className="text-sm">{error}</span>
          </div>
        )}

        {/* Visualizer */}
        <div className="flex justify-center items-end gap-1 h-24 mb-8">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className={`
                w-2 rounded-full transition-all duration-300
                ${isDarkMode ? 'bg-gradient-to-t from-purple-500 to-pink-500' : 'bg-gradient-to-t from-purple-600 to-pink-600'}
                ${isPlaying ? 'animate-pulse' : ''}
                ${isLoading ? 'animate-pulse opacity-50' : ''}
              `}
              style={{
                height: isPlaying 
                  ? `${Math.random() * 80 + 20}%` 
                  : isLoading 
                    ? `${Math.random() * 40 + 10}%`
                    : '20%',
                animationDelay: `${i * 0.05}s`,
                transitionDuration: isPlaying ? '300ms' : '1000ms'
              }}
            />
          ))}
        </div>

        {/* Station Selector */}
        <div className="mb-8">
          <select
            value={currentStation.streamUrl}
            onChange={(e) => handleStationChange(e.target.value)}
            className={`
              w-full px-4 py-3 rounded-xl
              transition-all duration-300
              focus:outline-none focus:ring-2
              ${isDarkMode 
                ? 'bg-gray-700 text-white border border-gray-600 focus:border-purple-500 focus:ring-purple-500/20' 
                : 'bg-gray-100 text-gray-800 border border-gray-300 focus:border-purple-500 focus:ring-purple-500/20'
              }
            `}
          >
            {radioStations.map((station) => (
              <option key={station.streamUrl} value={station.streamUrl}>
                {station.name}
              </option>
            ))}
          </select>
        </div>

        {/* Controls */}
        <div className="flex items-center justify-center gap-4 mb-6">
          <button
            onClick={togglePlayPause}
            disabled={isLoading || !canPlay}
            className={`
              w-16 h-16 rounded-full
              flex items-center justify-center
              transition-all duration-300
              ${(isLoading || !canPlay) 
                ? 'opacity-50 cursor-not-allowed' 
                : 'hover:scale-110 active:scale-95'
              }
              ${isPlaying 
                ? 'bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700' 
                : 'bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600'
              }
              text-white shadow-lg
            `}
          >
            {isLoading ? (
              <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : isPlaying ? (
              <Pause className="w-6 h-6" />
            ) : (
              <Play className="w-6 h-6 ml-1" />
            )}
          </button>
        </div>

        {/* Status Indicator */}
        <div className="text-center mb-4">
          <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs ${
            isDarkMode ? 'bg-gray-700 text-gray-300' : 'bg-gray-100 text-gray-600'
          }`}>
            <div className={`w-2 h-2 rounded-full ${
              isPlaying ? 'bg-green-500 animate-pulse' : 
              isLoading ? 'bg-yellow-500 animate-pulse' : 
              canPlay ? 'bg-blue-500' : 'bg-gray-400'
            }`} />
            <span>
              {isPlaying ? 'Streaming' : 
               isLoading ? 'Buffering...' : 
               canPlay ? 'Ready' : 'Loading...'}
            </span>
          </div>
        </div>

        {/* Volume Control */}
        <div className="flex items-center gap-3">
          <Volume2 className={`w-5 h-5 ${
            isDarkMode ? 'text-gray-400' : 'text-gray-600'
          }`} />
          <input
            type="range"
            min="0"
            max="1"
            step="0.05"
            value={volume}
            onChange={(e) => setVolume(parseFloat(e.target.value))}
            className="flex-1 h-2 rounded-lg appearance-none cursor-pointer"
            style={{
              background: `linear-gradient(to right, ${
                isDarkMode ? '#8B5CF6' : '#9333EA'
              } 0%, ${
                isDarkMode ? '#8B5CF6' : '#9333EA'
              } ${volume * 100}%, ${
                isDarkMode ? '#374151' : '#E5E7EB'
              } ${volume * 100}%, ${
                isDarkMode ? '#374151' : '#E5E7EB'
              } 100%)`
            }}
          />
          <span className={`text-sm w-10 text-right ${
            isDarkMode ? 'text-gray-400' : 'text-gray-600'
          }`}>
            {Math.round(volume * 100)}%
          </span>
        </div>
      </div>
    </div>
  )
}