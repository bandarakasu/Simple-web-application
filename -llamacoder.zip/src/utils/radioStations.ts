export const radioStations = [
  {
    name: "Hiru FM",
    streamUrl: "https://radio.lotustechnologieslk.net:2020/stream/hirufmgarden"
  },
  {
    name: "Siyatha FM",
    streamUrl: "https://srv01.onlineradio.voaplus.com/siyathafm"
  },
  {
    name: "Lakhanda",
    streamUrl: "https://cp12.serverse.com/proxy/itnfm?mp=/stream"
  },
  {
    name: "Sirasa FM",
    streamUrl: "https://mbc.thestreamtech.com:8087/index.html"
  },
  {
    name: "Neth FM",
    streamUrl: "https://cp11.serverse.com/proxy/nethfm/stream"
  },
  {
    name: "FM Derana",
    streamUrl: "https://cp12.serverse.com/proxy/fmderana/stream"
  },
  {
    name: "Tamil FM",
    streamUrl: "http://shaincast.caster.fm:47814/listen.mp3"
  },
  {
    name: "Shree FM",
    streamUrl: "http://207.148.74.192:7860/stream2.mp3"
  },
  {
    name: "Ran FM",
    streamUrl: "http://207.148.74.192:7860/ran.mp3"
  },
  {
    name: "SLBC",
    streamUrl: "http://220.247.227.6:8000/Snsstream"
  },
  {
    name: "City FM",
    streamUrl: "http://220.247.227.20:8000/citystream"
  },
  {
    name: "Y FM",
    streamUrl: "https://mbc.thestreamtech.com:7032/index.html"
  },
  {
    name: "Vasantham FM",
    streamUrl: "https://cp12.serverse.com/proxy/vasanthamfm?mp=/stream"
  },
  {
    name: "Shakthi FM",
    streamUrl: "https://mbc.thestreamtech.com:8086/index.html"
  },
  {
    name: "TNL Now",
    streamUrl: "http://live.tnlrn.com:8010/live.mp3"
  },
  {
    name: "Red FM",
    streamUrl: "http://shaincast.caster.fm:47830/listen.mp3"
  },
  {
    name: "Yes FM",
    streamUrl: "https://mbc.thestreamtech.com:7056/index.html"
  },
  {
    name: "E FM",
    streamUrl: "http://207.148.74.192:7860/stream.mp3"
  }
]