# Initialize git if not already done
git init
git add .
git commit -m "Initial commit - Sampath Portfolio with Radio Player"

# Push to GitHub
git branch -M main
git remote add origin https://github.com/yourusername/sampath-portfolio.git
git push -u origin main